
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int NOT NULL,
  `alternate_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'https://www.syntrawest.be',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `filename`, `type`, `size`, `alternate_text`, `created_at`, `deleted_at`) VALUES
(1, 'Blog1', 'test 1', 'adidas2025_01_30_14_38_46.webp', 'image/webp', 3620, 'anonymous', '2025-01-30 13:34:31', '0000-00-00 00:00:00'),
(2, 'tt', 'tt', 'anonymous-mask-hackers-2-1024x5852025_01_30_14_42_29.webp', 'image/webp', 24002, 'color', '2025-01-30 13:34:45', '0000-00-00 00:00:00'),
(3, 'johan', 'johan', 'johandeneve2025_01_30_14_34_56.png', 'image/png', 691189, 'johan', '2025-01-30 13:34:56', '0000-00-00 00:00:00'),
(4, 'logo', 'log', 'logo2025_01_30_14_35_07.png', 'image/png', 215518, 'log', '2025-01-30 13:35:07', '0000-00-00 00:00:00'),
(5, 'test', 'test', 'adidas2025_01_30_14_41_35.webp', 'image/webp', 3620, 'NULL', '2025-01-30 13:41:35', '0000-00-00 00:00:00'),
(6, 'tt', 'tt', 'adidas2025_01_30_14_42_44.webp', 'image/webp', 3620, 'NULL', '2025-01-30 13:42:44', '0000-00-00 00:00:00'),
(7, 'Blog1', 'test 1', 'kledij2025_01_30_14_44_14.jpg', 'image/jpeg', 85262, 'NULL', '2025-01-30 13:44:14', '0000-00-00 00:00:00'),
(8, 'test', 'test', 'eyVeRQ83SyCqLhzEvVKJvw2025_01_30_14_52_15.webp', 'image/webp', 1074726, 'NULL', '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(9, 'test', 'test', '10000179162025_02_01_12_01_45.jpg', 'image/jpeg', 434595, 'NULL', '2025-01-30 13:52:24', '0000-00-00 00:00:00'),
(10, 'dd', 'dd', '10000179162025_02_01_12_02_04.jpg', 'image/jpeg', 434595, 'NULL', '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(11, 'd', 'd', '10000179542025_02_01_12_02_21.jpg', 'image/jpeg', 574624, 'NULL', '2025-02-01 11:02:21', '0000-00-00 00:00:00'),
(12, 'dd', 'dd', '10000219182025_02_01_12_12_52.jpg', 'image/jpeg', 1172301, 'NULL', '2025-02-01 11:12:52', '0000-00-00 00:00:00'),
(13, 'dd', 'dd', '10000222212025_02_01_12_13_09.jpg', 'image/jpeg', 478077, 'NULL', '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(14, 'dd', 'dd', '10000179162025_02_01_13_17_46.jpg', 'image/jpeg', 434595, 'NULL', '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(15, 'ddsf', 'dsdfs', '10000321332025_02_01_13_32_58.jpg', 'image/jpeg', 527858, 'NULL', '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(16, 'dd', 'dd', '10000221482025_02_01_13_33_52.jpg', 'image/jpeg', 514212, 'NULL', '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(17, 'dd', 'dd', '1000022224(1)2025_02_01_13_35_01.jpg', 'image/jpeg', 546877, 'NULL', '2025-02-01 12:35:01', '0000-00-00 00:00:00'),
(18, 'dsdsf', 'sdffd', '10000350472025_02_01_13_37_12.jpg', 'image/jpeg', 402049, 'NULL', '2025-02-01 12:37:12', '0000-00-00 00:00:00'),
(19, 'dd', 'dsfds', '10000222212025_02_02_10_23_46.jpg', 'image/jpeg', 478077, 'NULL', '2025-02-02 09:23:46', '0000-00-00 00:00:00');
