
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs_categories`
--

DROP TABLE IF EXISTS `blogs_categories`;
CREATE TABLE IF NOT EXISTS `blogs_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blog_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs_categories`
--

INSERT INTO `blogs_categories` (`id`, `blog_id`, `category_id`) VALUES
(1, NULL, 2),
(2, NULL, 1),
(6, 13, 2),
(5, 19, 1);
