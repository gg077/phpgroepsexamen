-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 10 feb 2025 om 14:32
-- Serverversie: 8.3.0
-- PHP-versie: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbgroepsexamen`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `author_id`, `title`, `description`, `created_at`, `deleted_at`) VALUES
(1, 1, 'Blog1', 'test 1', '2025-01-29 08:38:40', '0000-00-00 00:00:00'),
(2, 1, 'tt', 'tt', '2025-01-29 08:40:31', '0000-00-00 00:00:00'),
(3, 1, 'dd', 'dd', '2025-01-29 08:44:25', '2025-01-30 13:52:46'),
(4, 1, 'tt', 'tt', '2025-01-29 08:46:10', '0000-00-00 00:00:00'),
(5, 1, 'test', 'test', '2025-01-30 13:37:55', '0000-00-00 00:00:00'),
(6, 1, 'test', 'test', '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(7, 1, 'dd', 'dd', '2025-02-01 10:11:22', '0000-00-00 00:00:00'),
(8, 1, 'd', 'd', '2025-02-01 10:12:41', '0000-00-00 00:00:00'),
(9, 1, 'dd', 'dd', '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(10, 1, 'dd', 'dd', '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(11, 1, 'test', 'NULL', '2025-02-01 12:05:50', '0000-00-00 00:00:00'),
(12, 1, 'testddssd', 'NULL', '2025-02-01 12:09:31', '0000-00-00 00:00:00'),
(13, 1, 'dd', 'dsfds', '2025-02-01 12:11:03', '0000-00-00 00:00:00'),
(14, 1, 'dd', 'NULL', '2025-02-01 12:11:59', '0000-00-00 00:00:00'),
(15, 1, 'dd', 'dd', '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(16, 1, 'ddsf', 'dsdfs', '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(17, 1, 'dd', 'dd', '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(18, 1, 'dd', 'dd', '2025-02-01 12:35:01', '2025-02-02 09:24:01'),
(19, 1, 'hallo', 'sdffd', '2025-02-01 12:37:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs_categories`
--

DROP TABLE IF EXISTS `blogs_categories`;
CREATE TABLE IF NOT EXISTS `blogs_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blog_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs_categories`
--

INSERT INTO `blogs_categories` (`id`, `blog_id`, `category_id`) VALUES
(1, NULL, 2),
(2, NULL, 1),
(6, 13, 2),
(10, 19, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs_photos`
--

DROP TABLE IF EXISTS `blogs_photos`;
CREATE TABLE IF NOT EXISTS `blogs_photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blog_id` int NOT NULL,
  `photo_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs_photos`
--

INSERT INTO `blogs_photos` (`id`, `blog_id`, `photo_id`) VALUES
(1, 1, 7),
(2, 2, 6),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 7, 12),
(7, 8, 11),
(8, 9, 10),
(9, 10, 13),
(10, 13, 19),
(11, 15, 14),
(12, 16, 15),
(14, 18, 17),
(16, 17, 40),
(17, 17, 16);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `deleted_at`) VALUES
(1, 'sport', '2025-02-01 11:58:51', '0000-00-00 00:00:00'),
(2, 'news', '2025-02-01 12:11:59', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int NOT NULL,
  `alternate_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'https://www.syntrawest.be',
  `user_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `filename`, `type`, `size`, `alternate_text`, `user_id`, `created_at`, `deleted_at`) VALUES
(1, 'Blog1', 'test 1', 'adidas2025_01_30_14_38_46.webp', 'image/webp', 3620, 'anonymous', 0, '2025-01-30 13:34:31', '0000-00-00 00:00:00'),
(2, 'tt', 'tt', 'anonymous-mask-hackers-2-1024x5852025_01_30_14_42_29.webp', 'image/webp', 24002, 'color', 0, '2025-01-30 13:34:45', '0000-00-00 00:00:00'),
(3, 'johan', 'johan', 'johandeneve2025_01_30_14_34_56.png', 'image/png', 691189, 'johan', 0, '2025-01-30 13:34:56', '0000-00-00 00:00:00'),
(4, 'logo', 'log', 'logo2025_01_30_14_35_07.png', 'image/png', 215518, 'log', 0, '2025-01-30 13:35:07', '0000-00-00 00:00:00'),
(5, 'test', 'test', 'adidas2025_01_30_14_41_35.webp', 'image/webp', 3620, 'NULL', 0, '2025-01-30 13:41:35', '0000-00-00 00:00:00'),
(6, 'tt', 'tt', 'adidas2025_01_30_14_42_44.webp', 'image/webp', 3620, 'NULL', 0, '2025-01-30 13:42:44', '0000-00-00 00:00:00'),
(7, 'Blog1', 'test 1', 'kledij2025_01_30_14_44_14.jpg', 'image/jpeg', 85262, 'NULL', 0, '2025-01-30 13:44:14', '0000-00-00 00:00:00'),
(8, 'test', 'test', 'eyVeRQ83SyCqLhzEvVKJvw2025_01_30_14_52_15.webp', 'image/webp', 1074726, 'NULL', 0, '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(9, 'test', 'test', '10000179162025_02_01_12_01_45.jpg', 'image/jpeg', 434595, 'NULL', 0, '2025-01-30 13:52:24', '0000-00-00 00:00:00'),
(10, 'dd', 'dd', '10000179162025_02_01_12_02_04.jpg', 'image/jpeg', 434595, 'NULL', 0, '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(11, 'd', 'd', '10000179542025_02_01_12_02_21.jpg', 'image/jpeg', 574624, 'NULL', 0, '2025-02-01 11:02:21', '0000-00-00 00:00:00'),
(12, 'dd', 'dd', '10000219182025_02_01_12_12_52.jpg', 'image/jpeg', 1172301, 'NULL', 0, '2025-02-01 11:12:52', '0000-00-00 00:00:00'),
(13, 'dd', 'dd', '10000222212025_02_01_12_13_09.jpg', 'image/jpeg', 478077, 'NULL', 0, '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(14, 'dd', 'dd', '10000179162025_02_01_13_17_46.jpg', 'image/jpeg', 434595, 'NULL', 0, '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(15, 'ddsf', 'dsdfs', '10000321332025_02_01_13_32_58.jpg', 'image/jpeg', 527858, 'NULL', 0, '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(16, 'dd', 'dd', '10000221482025_02_01_13_33_52.jpg', 'image/jpeg', 514212, 'NULL', 0, '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(17, 'dd', 'dd', '1000022224(1)2025_02_01_13_35_01.jpg', 'image/jpeg', 546877, 'NULL', 0, '2025-02-01 12:35:01', '0000-00-00 00:00:00'),
(19, 'dd', 'dsfds', '10000222212025_02_02_10_23_46.jpg', 'image/jpeg', 478077, 'NULL', 0, '2025-02-02 09:23:46', '0000-00-00 00:00:00'),
(20, 'NULL', 'NULL', 'honor2025_02_08_19_50_24.png', 'image/png', 674909, 'NULL', 1, '2025-02-08 18:50:24', '0000-00-00 00:00:00'),
(21, 'NULL', 'NULL', 'honor2025_02_08_19_50_53.png', 'image/png', 674909, 'NULL', 1, '2025-02-08 18:50:53', '0000-00-00 00:00:00'),
(22, 'NULL', 'NULL', 'Schermafbeelding 2024-12-05 1050582025_02_08_19_51_02.png', 'image/png', 47109, 'NULL', 1, '2025-02-08 18:51:02', '0000-00-00 00:00:00'),
(23, 'NULL', 'NULL', 'Schermafbeelding 2024-12-05 1050582025_02_08_19_51_23.png', 'image/png', 47109, 'NULL', 1, '2025-02-08 18:51:23', '2025-02-10 08:52:12'),
(24, 'NULL', 'NULL', 'Schermafbeelding 2024-12-10 1105432025_02_10_10_00_45.png', 'image/png', 57557, 'NULL', 1, '2025-02-10 09:00:45', '0000-00-00 00:00:00'),
(25, 'NULL', 'NULL', '1000022224(1)2025_02_01_13_35_012025_02_10_10_06_10.jpg', 'image/jpeg', 546877, 'NULL', 1, '2025-02-10 09:06:10', '0000-00-00 00:00:00'),
(26, 'NULL', 'NULL', '1000022224(1)2025_02_01_13_35_012025_02_10_10_06_17.jpg', 'image/jpeg', 546877, 'NULL', 1, '2025-02-10 09:06:17', '0000-00-00 00:00:00'),
(27, 'NULL', 'NULL', '1000022224(1)2025_02_01_13_35_012025_02_10_10_16_56.jpg', 'image/jpeg', 546877, 'NULL', 1, '2025-02-10 09:16:56', '0000-00-00 00:00:00'),
(28, 'NULL', 'NULL', '10000179162025_02_01_13_17_462025_02_10_10_17_07.jpg', 'image/jpeg', 434595, 'NULL', 1, '2025-02-10 09:17:07', '0000-00-00 00:00:00'),
(29, 'honer', 'hello world', 'cropped_17391807712025_02_10_10_19_49.png', 'image/png', 243431, 'honer', 1, '2025-02-10 09:19:49', '0000-00-00 00:00:00'),
(30, 'honer', 'hello world', 'cropped_17391804992025_02_10_10_21_25.png', 'image/png', 435548, 'NULL', 1, '2025-02-10 09:21:25', '0000-00-00 00:00:00'),
(31, 'NULL', 'NULL', 'Schermafbeelding 2024-12-17 1051292025_02_10_11_56_02.png', 'image/png', 567784, 'NULL', 1, '2025-02-10 10:56:02', '0000-00-00 00:00:00'),
(32, 'NULL', 'NULL', 'Schermafbeelding 2024-12-17 1004572025_02_10_11_56_37.png', 'image/png', 674909, 'NULL', 1, '2025-02-10 10:56:37', '0000-00-00 00:00:00'),
(33, 'NULL', 'NULL', 'ranking2025_02_10_12_53_35.png', 'image/png', 300109, 'NULL', 1, '2025-02-10 11:53:35', '0000-00-00 00:00:00'),
(34, 'NULL (Cropped)', 'NULL', 'cropped_1739194595.png', 'image/png', 209662, 'NULL', 1, '2025-02-10 12:36:35', '0000-00-00 00:00:00'),
(35, 'NULL', 'NULL', 'Schermafbeelding 2025-02-08 1500392025_02_10_13_43_48.png', 'image/png', 1191433, 'NULL', 1, '2025-02-10 12:43:48', '0000-00-00 00:00:00'),
(36, 'NULL', 'NULL', 'cropped_17391920592025_02_10_13_45_25.png', 'image/png', 166903, 'NULL', 1, '2025-02-10 12:45:25', '0000-00-00 00:00:00'),
(37, 'NULL', 'NULL', 'cropped_17391920592025_02_10_13_57_04.png', 'image/png', 166903, 'NULL', 1, '2025-02-10 12:57:04', '0000-00-00 00:00:00'),
(38, 'NULL', 'NULL', '10000222212025_02_01_12_13_092025_02_10_14_01_09.jpg', 'image/jpeg', 478077, 'NULL', 1, '2025-02-10 13:01:09', '0000-00-00 00:00:00'),
(39, 'NULL', 'NULL', 'Schermafbeelding 2024-12-10 1105432025_02_10_14_01_38.png', 'image/png', 57557, 'NULL', 1, '2025-02-10 13:01:38', '0000-00-00 00:00:00'),
(40, 'NULL', 'NULL', 'Schermafbeelding 2024-12-05 1050582025_02_10_14_25_05.png', 'image/png', 47109, 'NULL', 1, '2025-02-10 13:25:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `email`, `google_id`, `password`, `first_name`, `last_name`, `created_at`, `deleted_at`) VALUES
(1, 'Tom@gmail.com', NULL, '$2y$10$7tvfWSSAf1mqRxr74EUGl.ubLnLOhEPDn.NhiKR4D7MkpPxc3BreC', 'Tom', 'Vanhoutte', '2025-01-27 11:39:33', '2025-02-03 13:43:33'),
(2, 'Tim', 'NULL', '$2y$10$QYMIFbCA68KvYCeM10LO8erUtfm6MHSHjL9E4z2NEKVh7wmpj6jaa', 'Tim', 'Vanhoutte', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(3, 'test', NULL, 'test', 'test', 'WILLIAMS', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(4, 'test', NULL, 'test', 'Ike', 'WILLIAMS', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(6, 'ttt', NULL, 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(7, 'test', NULL, 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(8, 'test', NULL, 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(9, 'test', NULL, 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(10, 'test', NULL, 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(11, 'tester', NULL, '12345678', 'tester', 'tester', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(12, 'ttt', NULL, 'ttt', 'ttt', 'ttt', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(13, 'dsdsfds', NULL, 'ddssd', 'dsdsf', 'dsds', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(14, 'ddd', NULL, 'ddd', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(15, 'ddd', NULL, 'ddd', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(16, 'dsdds', NULL, 'dsdsds', 'dsds', 'dsdds', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(17, 'dsds', NULL, 'sdsd', 'dsdd', 'dsds', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(18, 'esdsdf', NULL, 'sddsffsd', 'sdffds', 'sddsffsd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(19, 'dsffds', NULL, 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(20, 'dsffds', NULL, 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(21, 'dfsdf', NULL, 'fdsfsd', 'dfdfsds', 'dsfdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(22, 'dfsdf', NULL, 'fdsfsd', 'dfdfsds', 'dsfdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(23, 'dsffds', NULL, 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(24, 'cxvcvx', NULL, 'cxcvx', 'cxcxv', 'cxcvx', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(25, 'dsdsfdsf', NULL, 'dsffdsdf', 'dsfdsfsdf', 'dsfdsdfs', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(26, 'ddsf', NULL, 'dfsdf', 'dsfdsf', 'dsdsfsdf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(27, 'dsfdsf', NULL, 'sddfssdf', 'dsdsf', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(28, 'aaa', NULL, 'aaa', 'aaa', 'aaa', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(29, 'test1', NULL, 'test1', 'test1', 'test1', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(30, 'test2', NULL, 'test2', 'test2', 'test2', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(31, 'test3', NULL, 'test3', 'test3d', 'test3', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(32, 'test4', NULL, 'test4', 'test4', 'test4', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(33, '', NULL, '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(34, 'test5', NULL, 'test5', 'test5', 'test5', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(36, 'test10', NULL, 'test10', 'test10', 'test10', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(38, 'test20', NULL, 'test20', 'test20', 'test20', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(41, 'test234', NULL, 'test234', 'test234', 'test234', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(43, 'ttt', NULL, '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(44, 'ttt', NULL, '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(45, 'ttt', NULL, '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(46, 'ttt', NULL, 'NULL', 'NULL', 'NULL', '2025-01-27 11:39:33', '2025-01-27 11:20:07'),
(47, 'tttddd', NULL, 'NULL', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(48, 'tttddd', NULL, 'NULL', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(51, 'tttddd', NULL, 'NULL', 'ddddd', 'dddddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(53, 'dsfdfs', NULL, 'dsdsfsdf', 'dsdsfsdf', 'sddsf', '2025-01-27 11:39:33', '2025-01-27 10:41:18'),
(54, 'testje', NULL, 'dsdsfds', 'dsfdsdf', 'dsdsfds', '2025-01-27 11:39:33', '0000-00-00 00:00:00'),
(55, 'test', NULL, '123', 'test', 'test', '0000-00-00 00:00:00', '2025-01-27 11:35:16'),
(56, 'ddd', NULL, 'ddd', 'ddd', 'ddd', '2025-01-27 11:33:33', '2025-01-27 12:02:28'),
(57, 'dddddd', NULL, 'ddddd', 'ddddddd', 'ddddd', '2025-01-27 11:51:13', '0000-00-00 00:00:00'),
(66, 'teamvs.agency@gmail.com', '101879086081177362042', '$2y$10$foZTVm0bCeEg2VfgN5Tr/.29AshnxqvjgyVLKkSfSLPqJlEfs8ikq', 'Verified', 'Solutions', '2025-02-06 11:32:19', '0000-00-00 00:00:00');

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `blogs_photos`
--
ALTER TABLE `blogs_photos`
  ADD CONSTRAINT `blogs_photos_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `blogs_photos_ibfk_2` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
